const mongoose = require("../connect");
var mon = require('mongoose');
var Schema = mon.Schema;
var detallehomeSchema = new Schema({
  menus: {
    type: Schema.Types.ObjectId,
    ref: "Menushome"
    },
    orden: {
      type: Schema.Types.ObjectId,
      ref: "Ordenhome"
      },
  cantidad: Number,
  precio : Number
});
var detalle = mongoose.model("Detallehome", detallehomeSchema);
module.exports = detallehome;
