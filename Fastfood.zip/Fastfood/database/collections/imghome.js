const mongoose = require("../connect");
var mon = require('mongoose');
 var Schema = mon.Schema;
var imgSchema = new Schema({
  name : String,
  idhome: String,
  physicalpath : String,
  relativepath : String
});
var imghome = mongoose.model("Imghome", imghomeSchema);
module.exports = imghome;
