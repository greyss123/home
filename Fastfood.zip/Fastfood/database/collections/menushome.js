const mongoose = require("../connect");
const Schema = mongoose.Schema;

var menushomeSchema = Schema({

    home: {
        type: Schema.Types.ObjectId,
        ref: "Home"
    },
    nombre: String,
    precio: {
        type: Number
    },
    descripcion: String,
    fechaRegistro: {
        type: Date,
        default: Date.now()
    },
    foto: String
})
//Nombre, precio, descripción, fechaderegistro, fotografía del producto

const menushome = mongoose.model("Menushome", menushomeSchema);
module.exports = menushome;
